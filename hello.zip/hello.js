
console.log("Hello World");
